# app.py
# (Full code was already shared by the user.)
# Placeholder note: This is the same file the user pasted.
# For GitHub, you should include your full app.py as you shared.

print("Run this with: python app.py")
